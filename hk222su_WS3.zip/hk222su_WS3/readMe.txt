The jar and bat file is in out/artifacts/blackjack_java_jar

For Linux users
Open the terminal and in the this folder location enter:
	chmod +x runProgram.bat #makes it executable
	./runProgram.bat  # runs the program in the terminal
	
	
For Windows users
Should be enough to double click the runProgram.bat

The updated class diagram is named updatedDiagram.png and is located in the same folder as this text file, it has only the parts I updated, not the full diagram
