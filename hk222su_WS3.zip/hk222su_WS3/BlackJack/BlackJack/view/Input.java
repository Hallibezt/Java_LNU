package BlackJack.view;

public enum Input {Play,Hit, Stand, Quit, wrong}

