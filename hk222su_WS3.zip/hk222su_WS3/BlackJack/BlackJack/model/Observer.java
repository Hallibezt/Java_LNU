package BlackJack.model;

public interface Observer {

      void Update() throws InterruptedException;
}
