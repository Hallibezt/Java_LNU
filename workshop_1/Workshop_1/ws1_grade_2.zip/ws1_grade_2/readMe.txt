Workshop 1 – grade two for peer review

Group members: Haraldur Blöndal Kristjánsson 

My assumptions:

     I assume the member is already registered.
     I assume that you can be member even though you do not register/own a boat. You can be part of the club and book events and so on (probably not a member if you are at least not a boat enthusiast).
     
     I assume that even though boat has many owners, only one is responsible for it at the club (the member who registers it) and therefor the boat has one owner in the system.
     
     For boat registration the system will also need registration number that is used to differ between boats in case the same owner books two identical boats. If the boat has no official registration 	number then it gets a sudo one (like when booking a canoe).
     
     I assume that member can book an event and the event might have a price to pay.
     
     I assume that only secretary can change information about a boat and delete it in the system. This is so that the employees do not need to double check all boat all the time to see if they fit the 	registry and membership fees.
     
     I assume that berths need to hold a list of previous owners so they can be prioritized to members that have had them before and I assume that the club has only berths for 200 boats but no 	    restrictions for number of members.
     
     Based on the season requirements I assume that the boat fee is split up to registration fee(fixed and if not charged for members booking early) and fee based on size and type.
    
     I assume that the club offers winter berths(with priority to their berth for main season) since the pre/off-season booking do not get berths right away – so those berth bookings go to a queue that 	is assigned berths just before the season starts.
    
      
