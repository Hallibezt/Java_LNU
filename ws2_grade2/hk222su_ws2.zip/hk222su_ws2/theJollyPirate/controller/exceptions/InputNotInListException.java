package controller.exceptions;


public class InputNotInListException extends Exception {
        public InputNotInListException(String message) {
            super(message);
        }
}
