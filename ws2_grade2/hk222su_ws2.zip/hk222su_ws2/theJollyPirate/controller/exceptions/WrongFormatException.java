package controller.exceptions;

public class WrongFormatException extends Exception{

    public WrongFormatException(String message) {
        super(message);
    }
}
