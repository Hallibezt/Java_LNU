package model.enums;

import com.sun.tools.javac.Main;

public enum MainOption {CreateMember, RemoveMember, editMember, FindMember, RegisterBoat, RemoveBoat, EditBoat, Compact, Verbose, Exit, WrongIn}
