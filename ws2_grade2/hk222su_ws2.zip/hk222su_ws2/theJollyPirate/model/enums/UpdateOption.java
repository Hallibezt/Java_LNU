package model.enums;

public enum UpdateOption {FirstName, SecondName, Password, RegisterBoat, RemoveBoat, Exit,WrongInput}
