package model.enums;

public enum UpdateBoatOption {Type, Length, Exit, WrongInput}
