
The jar is to be found under theJollyPirate/out/artifacts/

For Linux users
Open the terminal and in the this folder location enter:
	chmod +x runProgram.bat #makes it executable
	./runProgram.bat  # runs the program in the terminal
	
For Windows users
Should be enough to double click the runProgram.bat

Attention when member is created you are asked to create password, keep it single and remember it beause you are asked for it when you want to remove boat, update member etc.(everything that is needed to be access controled)

The program uses Berths, Fee and Price - I took it that way that the requirements statet what needed to be implemented, i.e. register boat - I implemented what the requirement "register boat" asked for and among other things it statet "return the PRICE of the booking for the member to accept/deny, update the FEE and allocate BERTH accordingly (based on previous users of the berth and so on)"

There is one member registered Haraldur Blöndal, you can see his information via compact/verbose list but if you want to edit/remove him you also need his password, which is: sykur
