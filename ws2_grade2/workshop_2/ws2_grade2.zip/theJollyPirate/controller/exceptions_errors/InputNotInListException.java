package controller.exceptions_errors;


public class InputNotInListException extends Exception {

        public InputNotInListException(String message) {
            super(message);
            }

}
