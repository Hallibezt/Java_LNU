package controller.exceptions_errors;

public class WrongFormatException extends Exception{

    public WrongFormatException(String message) {
        super(message);}
}
