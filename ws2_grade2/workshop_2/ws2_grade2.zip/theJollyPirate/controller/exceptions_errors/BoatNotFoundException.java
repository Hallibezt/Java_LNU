package controller.exceptions_errors;

public class BoatNotFoundException extends Exception{
    public BoatNotFoundException(String message) {
        super(message);}
}
