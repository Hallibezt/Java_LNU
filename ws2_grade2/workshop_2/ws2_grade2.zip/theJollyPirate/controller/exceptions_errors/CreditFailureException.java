package controller.exceptions_errors;

public class CreditFailureException extends Exception{
    public CreditFailureException(String message) {
        super(message);}
}
