package model.enums;

public enum UpdateOption {firstName, secondName, password, registerBoat, removeBoat, exit}
