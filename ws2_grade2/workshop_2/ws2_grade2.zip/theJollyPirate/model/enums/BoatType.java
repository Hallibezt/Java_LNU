package model.enums;

public enum BoatType {Motorsailer, Sailboat, Kayak_Canoe, Other}
