package model.enums;

public enum UpdateBoatOption {type, length, exit}
